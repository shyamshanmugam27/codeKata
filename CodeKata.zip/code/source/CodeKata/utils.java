package CodeKata;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2019-02-14 17:00:12 IST
// -----( ON-HOST: rhljnjconcertotest01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.regex.Matcher;
import java.util.regex.Pattern;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void findDelimiter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(findDelimiter)>> ---
		// @sigtype java 3.5
		// [i] field:0:required regex
		// [i] field:0:required input
		// [o] record:0:required resultSet
		// [o] - record:1:required result
		// [o] -- field:0:required text
		// pipeline
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		int sets = 0;
		int i = 0;
		
		//get Inputs
		String regex = IDataUtil.getString(pipelineCursor, "regex");
		String input = IDataUtil.getString(pipelineCursor, "input");
		
		
		//Pattern matching
		Pattern pattern = Pattern.compile(regex);	
		Matcher matcher = pattern.matcher(input);
		
		// to get the array size		
		while (matcher.find())
		{
		  sets++;
		}
		matcher.reset();
		
		// resultSet
		IData resultSet = IDataFactory.create();
		IDataCursor resultSetCursor = resultSet.getCursor();
		
		// resultSet.result
		IData[] result = new IData[sets];
		
		while (matcher.find())
		{
		  result[i] = IDataFactory.create();
		  IDataCursor resultCursor = result[i].getCursor();
		  IDataUtil.put(resultCursor, "text", matcher.group());
		  resultCursor.destroy();
		  IDataUtil.put(resultSetCursor, "result", result);
		  resultSetCursor.destroy();
		  i++;
		}
		
		IDataUtil.put(pipelineCursor, "resultSet", resultSet);
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void isNumeric (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isNumeric)>> ---
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] field:0:required isNumeric
		IDataCursor pipelineCursor = pipeline.getCursor();
		pipelineCursor.first("input");
		String input = (String) pipelineCursor.getValue();
		
		//initialize to true
		String isNumeric = "true";
		
		try
		{
		  float fNumber = Double.valueOf(input).floatValue();
		}
		catch (Exception e)
		{
		  isNumeric = "false";
		}
		finally
		{
		  pipelineCursor.insertAfter("isNumeric", isNumeric);
		  pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

