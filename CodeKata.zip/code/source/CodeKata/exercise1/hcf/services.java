package CodeKata.exercise1.hcf;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2019-02-14 16:52:31 IST
// -----( ON-HOST: rhljnjconcertotest01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.ArrayList;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void highestCommonFactor (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(highestCommonFactor)>> ---
		// @sigtype java 3.5
		// [i] field:1:required inputs
		// [o] object:0:required commonFactor
		// get the pipeline cursor
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		
		//get the inputs from user
			String[]	inputs = IDataUtil.getStringArray( pipelineCursor, "inputs" );
			int commonFactorVal = 0;
		
		// define the array list to hold the input values,
		ArrayList<Integer> inputArray = new ArrayList<Integer>();
		
		//  copy string array values to Integer array list
		if(inputs != null)
		{
		for(int j=0;j<inputs.length;j++)
			inputArray.add(Integer.parseInt(inputs[j]));
		}
		//get the common factor value
		if(inputArray.size() >0)
			commonFactorVal = findGCD(inputArray,inputs.length);
		
		// print the output
		IDataUtil.put( pipelineCursor, "commonFactor", commonFactorVal );
		
		//destroy the pipeline cursor
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	//recursive method to find the highest common factor
	public static int gcd(int x, int y) 
	    { 
		    int r;
		    while (y!=0) {
		        r = x%y;
		        x = y;
		        y = r;
		    }
		    return x;
	    } 
	
	//function to pass the input array list and length
	public static int findGCD(ArrayList<Integer> integers, int n) 
	    { 
		
	        int result = integers.get(0);
	        for (int k = 1;k < n; k++) 
	            result = gcd(integers.get(k), result); 
	  
	        return result; 
	    } 
	
		
	// --- <<IS-END-SHARED>> ---
}

